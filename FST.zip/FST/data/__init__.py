from data.celeba import CelebA
from data.celeba_blond_hair import CelebA as CelebA_B
from data.celeba_adv import CelebA_Adv
from data.LFW import LFW